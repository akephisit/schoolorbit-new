# 📘 Consecutive Periods Requirement - สรุปการทำงาน

## 🎯 ความเข้าใจที่ถูกต้อง

### **"วิชาต้อง 2 คาบติด" หมายถึง:**

```
✅ วันไหนที่มีเรียน ต้องเรียน 2 คาบติดกัน (หรือมากกว่า)
✅ แต่ไม่จำเป็นต้องเรียนทั้งหมดในวันเดียว
✅ สามารถแบ่งเป็นหลายวันได้
✅ อาจมี 1 คาบเดี่ยวได้ (ถ้า allow_single_period = true)
```

---

## 📊 ตัวอย่างที่ 1: พละ 3 คาบ/สัปดาห์

### **Configuration:**
```sql
min_consecutive_periods = 2
max_consecutive_periods = 2
allow_single_period = true  -- อนุญาต 1 คาบเดี่ยว
```

### **ตารางที่ถูกต้อง ✅**

**Option 1:** 2 คาบติด + 1 คาบเดี่ยว
```
จันทร์ คาบ 5-6: พละ (2 คาบติด) ✅
พฤหัส คาบ 3: พละ (1 คาบเดี่ยว) ✅

เหตุผล:
- วันจันทร์มี 2 คาบ → ติดกัน ✓
- วันพฤหัสมี 1 คาบ → OK เพราะ allow_single_period = true ✓
```

**Option 2:** วันเดียวครบ 3 คาบ (ไม่ได้!)
```
จันทร์ คาบ 5-7: พละ (3 คาบติด) ❌

เหตุผล:
- เกิน max_consecutive_periods (2) ✗
```

### **ตารางที่ผิด ❌**

**Wrong 1:** แยกเป็น 1 คาบ + 2 คาบ (ไม่ติดกัน)
```
จันทร์ คาบ 5: พละ (1 คาบ) ❌
พฤหัส คาบ 3-4: พละ (2 คาบ) ✅

เหตุผล:
- วันจันทร์มี 1 คาบ แต่ควรจัด 2 คาบให้ดีกว่า
  (เพราะมีเหลืออีก 2 คาบ ควรจัดเป็น 2+1 ไม่ใช่ 1+2)
```

**Wrong 2:** แยกทั้งหมด
```
จันทร์ คาบ 5: พละ (1 คาบ) ❌
พฤหัส คาบ 3: พละ (1 คาบ) ✅
ศุกร์ คาบ 4: พละ (1 คาบ) ✅

เหตุผล:
- ถ้า allow_single_period = true และมี 3 คาบ
  ควรจัดเป็น 2+1 ไม่ใช่ 1+1+1
```

---

## 📊 ตัวอย่างที่ 2: ปฏิบัติการเคมี 4 คาบ/สัปดาห์

### **Configuration:**
```sql
min_consecutive_periods = 2
max_consecutive_periods = 3
allow_single_period = false  -- ห้าม 1 คาบเดี่ยว!
```

### **ตารางที่ถูกต้อง ✅**

**Option 1:** 2+2
```
อังคาร คาบ 3-4: LAB (2 คาบติด) ✅
พฤหัส คาบ 5-6: LAB (2 คาบติด) ✅

เหตุผล:
- วันอังคาร 2 คาบติด ✓
- วันพฤหัส 2 คาบติด ✓
- ไม่มี 1 คาบเดี่ยว ✓
```

**Option 2:** 3+1 (ไม่ได้!)
```
อังคาร คาบ 3-5: LAB (3 คาบติด) ✅
พฤหัส คาบ 6: LAB (1 คาบเดี่ยว) ❌

เหตุผล:
- วันอังคาร 3 คาบติด (OK, ไม่เกิน max) ✓
- วันพฤหัส 1 คาบเดี่ยว (ผิด! allow_single_period = false) ✗
```

### **ตารางที่ผิด ❌**

**Wrong:** 2+1+1
```
อังคาร คาบ 3-4: LAB (2 คาบติด) ✅
พฤหัส คาบ 5: LAB (1 คาบ) ❌
ศุกร์ คาบ 3: LAB (1 คาบ) ❌

เหตุผล:
- allow_single_period = false
- ห้ามมี 1 คาบเดี่ยว!
```

---

## 📊 ตัวอย่างที่ 3: ศิลปะ 2 คาบ/สัปดาห์

### **Configuration:**
```sql
min_consecutive_periods = 2
max_consecutive_periods = 2
allow_single_period = false  -- ห้าม 1 คาบเดี่ยว
```

### **ตารางที่ถูกต้อง ✅**

**เพียงทางเดียว:** ทั้ง 2 คาบในวันเดียว
```
พฤหัส คาบ 5-6: ศิลปะ (2 คาบติด) ✅

เหตุผล:
- มีทั้งหมด 2 คาบ
- ต้อง 2 คาบติด
- ห้าม 1 คาบเดี่ยว
→ จัดวันเดียวครบ!
```

### **ตารางที่ผิด ❌**

```
จันทร์ คาบ 5: ศิลปะ (1 คาบ) ❌
พฤหัส คาบ 6: ศิลปะ (1 คาบ) ❌

เหตุผล:
- allow_single_period = false
- ต้องจัด 2 คาบติดกัน!
```

---

## 🔧 Algorithm Logic

### **Scheduling Strategy:**

```rust
fn schedule_consecutive_course(
    course: &Course,  // พละ 3 คาบ
    config: ConsecutiveRequirement {
        min_consecutive: 2,
        max_consecutive: 2,
        allow_single_period: true,
    }
) -> Vec<Assignment> {
    let total = course.periods_needed; // 3
    let min = config.min_consecutive;  // 2
    let max = config.max_consecutive;  // 2
    
    // Strategy: จัดกลุ่ม max ก่อน จนเหลือน้อยกว่า max
    let mut remaining = total;
    let mut assignments = vec![];
    
    // Round 1: จัด max (2 คาบ)
    if remaining >= max {
        assignments.push(schedule_consecutive_block(max)); // 2 คาบติด
        remaining -= max; // เหลือ 1
    }
    
    // Round 2: เหลือเท่าไหร่?
    if remaining > 0 {
        if remaining >= min {
            // เหลือ >= min → จัดติดกัน
            assignments.push(schedule_consecutive_block(remaining));
        } else if config.allow_single_period {
            // เหลือ < min แต่อนุญาต 1 คาบเดี่ยว
            assignments.push(schedule_single_period());
        } else {
            // เหลือ < min และไม่อนุญาต → ERROR!
            return Err("Cannot schedule: remainder < min and no single period allowed");
        }
    }
    
    Ok(assignments)
}

// ผลลัพถ์:
// Round 1: จันทร์ คาบ 5-6 (2 คาบติด)
// Round 2: พฤหัส คาบ 3 (1 คาบเดี่ยว - OK)
```

---

## 📝 Validation Rules

### **Rule 1: Check per day**
```
FOR each day WITH course periods:
    IF period_count == 1:
        IF NOT allow_single_period:
            ERROR "Single period not allowed"
    ELSE IF period_count >= 2:
        IF NOT is_consecutive(periods):
            ERROR "Periods must be consecutive"
        IF period_count < min_consecutive:
            ERROR "Too few consecutive"
        IF period_count > max_consecutive:
            ERROR "Too many consecutive"
```

### **Rule 2: Optimal arrangement**
```
เป้าหมาย: จัดให้ได้กลุ่ม max_consecutive มากที่สุด

Example: 5 คาบ, min=2, max=3, allow_single=true
✅ Best: 3 + 2 (ได้ 1 กลุ่ม max)
⚠️ OK: 2 + 2 + 1 (ไม่ได้ max แต่ valid)
❌ Bad: 2 + 1 + 1 + 1 (มี 1 คาบเดี่ยวเยอะเกิน)
```

---

## 💡 สรุป

| Config | มีทั้งหมด | จัดได้ | จัดไม่ได้ |
|--------|-----------|--------|----------|
| min=2, max=2, single=true | 3 คาบ | 2+1 | 1+2, 1+1+1, 3 |
| min=2, max=3, single=false | 4 คาบ | 2+2, 3+1❌ | 2+1+1 |
| min=2, max=2, single=false | 2 คาบ | 2 | 1+1 |
| min=1, max=2, single=true | 4 คาบ | ทุกแบบ | - |

---

**หมายเหตุ:** 
- ✅ = ถูกต้อง
- ⚠️ = ใช้ได้แต่ไม่ optimal
- ❌ = ผิด

**Last Updated:** 2026-02-08
